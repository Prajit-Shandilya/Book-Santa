import firebase from 'firebase';
import 'firebase/firestore'
require('@firebase/firestore')

var firebaseConfig = {
    apiKey: "AIzaSyBrMqgLQ4uXJcjp1bXsWsFejZJMEIN4yx8",
    authDomain: "book-santa-cf7e2.firebaseapp.com",
    projectId: "book-santa-cf7e2",
    storageBucket: "book-santa-cf7e2.appspot.com",
    messagingSenderId: "807859769853",
    appId: "1:807859769853:web:f4616ff0e2d91917cc8994"
  };
if(!firebase.apps.length){
firebase.initializeApp(firebaseConfig);
}
//var db=firebase.firestore()
export default firebase.firestore();
